using ASM1_1ST_APDP_Khiemtv_BH00934;

namespace SystemTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        // Test case for creating a new student
        [Test]
        public void CreateStudent_ValidData_ReturnsStudentInstance()
        {
            var student = new Student("Tran", "Khiem", "BH00934");

            Assert.AreEqual("Tran", student.FirstName);
            Assert.AreEqual("Khiem", student.LastName);
            Assert.AreEqual("BH00934", student.StudentID);
        }

        // Test case for creating a course and adding a subject
        [Test]
        public void CreateCourse_AddSubject_SubjectListIncreased()
        {
            var teacher = new Teacher("Dinh", "Van Dong", "T001");
            var course = new Course("CS101", "Introduction to Programming", teacher);
            var subject = new Subject { SubjectCode = "CS1011", SubjectName = "C#", Description = "Basic C# programming" };
            course.Subjects.Add(subject);

            Assert.Contains(subject, course.Subjects);
        }

        // Test case for setting a course instructor
        [Test]
        public void SetCourseInstructor_ValidTeacher_InstructorSet()
        {
            var teacher = new Teacher("Dinh", "Van Dong", "T001");
            var course = new Course("CS101", "Introduction to Programming", null);
            course.CourseInstructor = teacher;

            Assert.AreEqual(teacher, course.CourseInstructor);
        }

        // Test case for outputting a teacher's information
        [Test]
        public void TeacherToString_ValidTeacher_ReturnsCorrectString()
        {
            var teacher = new Teacher("Le", "Van Thuan", "T007");
            var stringRepresentation = teacher.ToString();

            StringAssert.AreEqualIgnoringCase("Teacher: Le Van Thuan, ID: T007", stringRepresentation);
        }

        // Test case for creating a department with no courses
        [Test]
        public void CreateDepartment_NoCourses_CoursesListIsEmpty()
        {
            var department = new Department { DepartmentName = "Computer Science" };

            Assert.IsEmpty(department.Courses);
        }
    }
}