﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM1_1ST_APDP_Khiemtv_BH00934
{
    public class Department
    {
        public string DepartmentName { get; set; }
        public List<Course> Courses { get; set; } = new List<Course>(); // Initialize the property inline
    }
}
