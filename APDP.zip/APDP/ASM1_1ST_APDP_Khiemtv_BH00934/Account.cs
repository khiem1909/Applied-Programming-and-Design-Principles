﻿namespace ASM1_1ST_APDP_Khiemtv_BH00934
{
    public class Account
    {
        private string username;
        private string password;

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Password
        {
            set { password = value; }
        }
    }

}
